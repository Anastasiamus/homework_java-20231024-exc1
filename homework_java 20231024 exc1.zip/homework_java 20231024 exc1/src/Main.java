public class Main {
    public static void main(String[] args) {
        System.out.println(x(1,2));
        System.out.println(x(1,2,3));
        System.out.println(x(1,2,3,4));
    }
    private static int x(int number1 , int number2){
        int result;
        result= number1*number2;
        return result;
    }
    private static int x(int number1,int number2,int number3){
        int result;
        result= number1*number2*number3;
        return result;
    }
    private static int x(int number1,int number2,int number3, int number4){
        int result;
        result= number1*number2*number3*number4;
        return result;
    }




}








// 1 уровень сложности: Задание 1.
//Сделайте перегруженные методы для перемножения 2-х, 3-х и 4-х чисел.
// В методе умножения 3-х чисел используйте вызов метода для 2-х чисел.
// В методе умножения 4-х чисел – вызов метода для 3-х чисел.